read input

case $input in
  1) echo "one"
  ;;
  2) echo "two"
  ;;
  3) echo "three"
  ;;
  *) echo "else"
  ;;
esac
