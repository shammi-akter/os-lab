str="why are you running ?"
sub=${str:0:7}
echo $sub
